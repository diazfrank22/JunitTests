INSERT INTO cuentas (persona, saldo) VALUES ('Andrés', 1000);
INSERT INTO cuentas (persona, saldo) VALUES ('John', 2000);
INSERT INTO bancos (nombre, total_transferencias) VALUES ('El banco financiero', 0);